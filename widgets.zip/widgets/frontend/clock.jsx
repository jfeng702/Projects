import React from 'react';

export default class Clock extends React.Component {

  constructor(props){
    super(props);
    this.props = props;
    this.state = { time: new Date() };
    this.tick = this.tick.bind(this);
    this.ticker = {};
  }

  tick() {
    this.setState({ time: new Date() });
  }

  componentDidMount() {
    this.ticker = setInterval(this.tick, 1000);
  }

  componentWillUnmount() {
    clearInterval(this.ticker);
  }

  render() {
    return (
      <div>

      <div class="clock">
        <h1 class="clock-title">Clock</h1>
        <div class="date">
          <h2>Date:</h2>
          { this.state.time.toLocaleDateString('en-US', {timezone: 'PST'}) }
        </div>

        <div class="time">
          <h2>Time:</h2>
          { this.state.time.toLocaleTimeString('en-US', {timezone: 'PST'}) }
        </div>
      </div>
      </div>
    );
  }
}
